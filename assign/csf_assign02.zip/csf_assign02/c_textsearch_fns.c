#include <stdio.h>
#include "textsearch_fns.h"

// TODO: implement functions declared in textsearch_fns.h
