#ifndef TEXTSEARCH_FNS_H
#define TEXTSEARCH_FNS_H

#define MAXLINE 511

// TODO: declare helper functions here (to be implemented in
// c_textsearch_fns.c and asm_textsearch_fns.S)

#endif // TEXTSEARCH_FNS_H
